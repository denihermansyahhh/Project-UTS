import service.*;
import entity.*;
import java.util.*;

public class Aplikasi {

    private static SuratmasukService service;
    private static Scanner scanner;

    public static void main(String[] args) {
        service = new SuratmasukService();
        scanner = new Scanner(System.in);

        int opsi = 5;
        do {
            tampilkanMenu();
            opsi = scanner.nextInt();
            seleksi(opsi);
        } while(opsi != 5);
    }

    private static void seleksi(int opsi) {
        switch(opsi) {
            case 1:
                callFormTambahData();
                break;
            case 2:
                callFormUbahData();
                break;
            case 3:
                callFormHapusData();
                break;
            case 4:
                service.tampilkanData();
                break;
        }
    }

    private static void callFormHapusData() {
        scanner = new Scanner(System.in);

        System.out.print("pengirim : ");
        String pengirim = scanner.nextLine();
        service.hapusData(pengirim);
    }

    private static void callFormUbahData() {
        scanner = new Scanner(System.in);
        String pengirim, alamatpengirim, tujuan;

        System.out.println("\n-= Form Ubah Data =-");
        System.out.print("pengirim : ");
        pengirim = scanner.nextLine();
        System.out.print("alamatpengirim : ");
        alamatpengirim = scanner.nextLine();
        System.out.print("tujuan : ");
        tujuan = scanner.nextLine();
        service.ubahData(new Suratmasuk(pengirim, alamatpengirim, tujuan));
    }

    private static void callFormTambahData() {
        scanner = new Scanner(System.in);
        String pengirim, alamatpengirim, tujuan;

        System.out.println("\n-= Form Tambah Data =-");
        System.out.print("pengirim : ");
        pengirim = scanner.nextLine();
        System.out.print("alamatpengirim : ");
        alamatpengirim = scanner.nextLine();
        System.out.print("tujuan : ");
        tujuan = scanner.nextLine();
        service.tambahData(new Suratmasuk(pengirim, alamatpengirim, tujuan));
    }

    private static void tampilkanMenu() {
        System.out.println("\n--== Aplikasi Suratmasuk ==--");
        System.out.println("1. Tambah Data");
        System.out.println("2. Ubah Data");
        System.out.println("3. Hapus Data");
        System.out.println("4. Tampilkan Data");
        System.out.println("5. KELUAR");
        System.out.println("----------------");
        System.out.print  ("opsi > ");
    }

}