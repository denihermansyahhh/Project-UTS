package entity;

public class Suratmasuk {

    private String pengirim;
    private String alamatpengirim;
    private String tujuan;


    public Suratmasuk(String pengirim, String alamatpengirim, String tujuan) {
        this.pengirim = pengirim;
        this.alamatpengirim = alamatpengirim;
        this.tujuan = tujuan;
    }

    public boolean equals(Object object) {
        Suratmasuk sm = (Suratmasuk) object;
        return pengirim.equals(sm.getPengirim());
    }

    public String getPengirim() {
        return pengirim;
    }

    public void setPengirim(String pengirim) {
        this.pengirim = pengirim;
    }

    public String getAlamatpengirim() {
        return alamatpengirim;
    }

    public void setAlamatpengirim(String alamatpengirim) {
        this.alamatpengirim = alamatpengirim;
    }

    public String getTujuan() {
        return tujuan;
    }

    public void setTujuan(String tujuan) {
        this.tujuan = tujuan;
    }
}