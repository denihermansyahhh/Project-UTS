package service;

import java.util.*;
import entity.*;

public class SuratmasukService {

    private static List<Suratmasuk> data = new LinkedList<Suratmasuk>();

    public void tambahData(Suratmasuk sm) {
        data.add(sm);
        System.out.println("data telah tersimpan");
    }

    public void ubahData(Suratmasuk sm) {
        int idx = data.indexOf(sm);
        if(idx >= 0) {
            data.set(idx, sm);
            System.out.println("data telah berubah");
        }
    }

    public void hapusData(String pengirim) {
        int idx = data.indexOf(new Suratmasuk(pengirim, "", ""));
        if(idx >= 0) {
            data.remove(idx);
            System.out.println("data telah terhapus");
        }
    }

    public void tampilkanData() {
        System.out.println("\n--= SURAT MASUK =--");
        int urutan = 1;
        for (Suratmasuk sm : data){
            System.out.println("data ke-" + urutan++);
            System.out.println("  pengirim : " + sm.getPengirim());
            System.out.println("  alamat pengirim : " + sm.getAlamatpengirim());
            System.out.println("  tujuan : " + sm.getTujuan());
        }
    }

}